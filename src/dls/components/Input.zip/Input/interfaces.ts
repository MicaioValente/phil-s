import type { Input } from 'tamagui';

export interface InputProps extends React.ComponentProps<typeof Input> {}
